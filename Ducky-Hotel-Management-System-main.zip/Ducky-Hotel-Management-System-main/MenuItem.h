#ifndef MENUITEM_H
#define MENUITEM_H

#include <string>

struct MenuItem {
    std::string name;
    double price;
};

#endif // MENUITEM_H
